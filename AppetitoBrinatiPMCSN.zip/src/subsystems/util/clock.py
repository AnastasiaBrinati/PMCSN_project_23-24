class Time:
    arrival = -1        # next arrival time                   */
    completion = -1     # next completion time                */
    current = -1        # current time                        */
    next = -1           # next (most imminent) event time     */
    last = -1           # last arrival time                   */
